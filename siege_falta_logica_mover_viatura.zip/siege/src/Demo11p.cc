#include "Demo11p.h"
//#include "TraCIDemo11pMessage_m.h"

using namespace veins;

Define_Module(veins::Demo11p);

void Demo11p::initialize(int stage)
{
    DemoBaseApplLayer::initialize(stage);

    if (stage == 0) {
        sentMessage = false;
        lastDroveAt = simTime();
        currentSubscribedServiceId = -1;
    }


}



void Demo11p::handleMessage(cMessage* msg){

}

void Demo11p::handleSelfMsg(cMessage* msg)
{

}

void Demo11p::handlePositionUpdate(cObject* obj)
{

}
