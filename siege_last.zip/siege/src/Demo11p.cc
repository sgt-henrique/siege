#include "Demo11p.h"

using namespace veins;

Define_Module(veins::Demo11p);

void Demo11p::initialize(int stage)
{

}

void Demo11p::handleSelfMsg(cMessage* msg)
{

}
