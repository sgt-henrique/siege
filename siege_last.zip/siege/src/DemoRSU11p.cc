#include "DemoRSU11p.h"

using namespace veins;

Define_Module(veins::DemoRSU11p);


