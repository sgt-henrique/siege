#include "Fugitivo.h"

using namespace veins;

Define_Module(veins::Fugitivo);

void Fugitivo::initialize(int stage)
{
    findHost()->getDisplayString().setTagArg("i", 1, "red");

}

