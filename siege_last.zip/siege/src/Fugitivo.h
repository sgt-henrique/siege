#pragma once

#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"

#ifndef FUGITIVO_H_
#define FUGITIVO_H_
namespace veins {


class VEINS_API Fugitivo : public DemoBaseApplLayer {
public:
    void initialize(int stage) override;

};
}

#endif /* FUGITIVO_H_ */
