#include "Fugitivo.h"
//#include "TraCIDemo11pMessage_m.h"

using namespace veins;

Define_Module(veins::Fugitivo);

void Fugitivo::initialize(int stage)
{
    //DemoBaseApplLayer::initialize(stage);

    findHost()->getDisplayString().setTagArg("i", 1, "red");

}

