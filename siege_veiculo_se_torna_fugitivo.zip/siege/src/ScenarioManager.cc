#include "ScenarioManager.h"

Define_Module(siege::ScenarioManager);

using namespace std;
using namespace veins;

namespace siege {

void ScenarioManager::initialize(int stage) {

    TraCIScenarioManagerLaunchd::initialize(stage);
    EV << "Meu ScenarioManager (siege) foi inicializado!" << endl;

    if (stage == 0) {
        // Agendar evento para sortear e designar o fugitivo após 5 segundos
        // Certifique-se de que os veículos já foram adicionados pelo SUMO/TraCI antes disso.
        cMessage* designateFugitivo = new cMessage("designateFugitivo");
        scheduleAt(simTime() + 5, designateFugitivo);

        //cMessage* setViaturas = new cMessage("setViaturas");
        //scheduleAt(simTime() + 5, setViaturas);
    }
}

void ScenarioManager::handleMessage(cMessage* msg) {
    EV << "ScenarioManager: mensagem recebida: " << msg->getName() << endl;

    if (strcmp(msg->getName(), "designateFugitivo") == 0) {
        EV << "Entrou no if: Designando fugitivo." << endl;
        designateRandomFugitivo(); // Nova função para sortear e designar
        delete msg; // Lembre-se de deletar a mensagem após o uso
        return;
    }
    if (strcmp(msg->getName(), "moveFugitivo") == 0) {
            EV << "Entrou no if: Movendo fugitivo para nova coordenada." << endl;
            // Exemplo de coordenada de destino (ajuste conforme sua necessidade)
            Coord targetCoord(500, 500); // Exemplo: X=500, Y=500
            moveFugitiveToCoordinate("fugitivo", targetCoord); // Assumindo que "fugitivo" é o ID do veículo
            delete msg;
            return;
        }

    if (msg->isSelfMessage()) {
        handleSelfMsg(msg);
        return;
    }
    throw cRuntimeError("erro no handleMessage de ScenarioManager)");
}

void ScenarioManager::designateRandomFugitivo() {
    // 1. Obter a lista de hosts gerenciados (veículos OMNeT++ com ID do SUMO)
    const std::map<std::string, cModule*>& managedHostsMap = getManagedHosts();

    // 2. Verificar a quantidade de veículos ativos
    // Embora activeVehicleCount exista, é mais direto usar o tamanho do mapa de hosts
    // gerenciados, pois ele já reflete os módulos OMNeT++ criados.
    if (managedHostsMap.empty()) {
        EV << "Nenhum veículo gerenciado encontrado no OMNeT++ para designar como fugitivo." << endl;
        return;
    }
    // 3. Criar um vetor de pares (ID SUMO, cModule*) para facilitar o sorteio por índice
    std::vector<std::pair<std::string, cModule*>> activeVehicles(managedHostsMap.begin(), managedHostsMap.end());


    // 4. Sortear um veículo aleatoriamente do vetor
    int randomIndex = omnetpp::intuniform(getParentModule()->getRNG(0), 0, activeVehicles.size() - 1);

    std::string fugitiveId = activeVehicles[randomIndex].first;
    cModule* fugitiveModule = activeVehicles[randomIndex].second;

    EV << "Veículo sorteado para ser o fugitivo: ID SUMO = " << fugitiveId << ", Módulo OMNeT++ = " << fugitiveModule->getFullName() << endl;


    // FAZER A VÍTIMA SURGIR NO LOCAL ONDE O VEÍCULO SE TORNOU FUGITIVO
    // FAZER SURGIREM AS VIATURAS DE MANEIRA ALEATÓRIA
    // ---------------------------------------

    // 5. Opcional: Mudar a cor do veículo no SUMO (para visualização)
    fugitiveModule->getDisplayString().setTagArg("i", 1, "red");

    //definir destino do fugitivo, mudar sua velocidade
    Coord targetCoord(500, 500);
    moveFugitiveToCoordinate(fugitiveId, targetCoord);

}
void ScenarioManager::moveFugitiveToCoordinate(const std::string& vehicleId, const Coord& targetCoord) {
    EV << "Tentando mover veículo " << vehicleId << " para a coordenada: ("
       << targetCoord.x << ", " << targetCoord.y << ")" << endl;

    // 1. Converter a coordenada OMNeT++ para uma posição no mapa rodoviário do SUMO
    std::tuple<std::string, double, uint8_t> roadMapPos = getCommandInterface()->getRoadMapPos(targetCoord);

    std::string targetRoadId = std::get<0>(roadMapPos);

    if (!targetRoadId.empty()) {
        // 2. Usar changeTarget para definir o novo destino do veículo. Isso fará com que o SUMO recalcule a rota para a nova estrada.
        getCommandInterface()->vehicle(vehicleId).changeTarget(targetRoadId);
        EV << "Veículo " << vehicleId << " redirecionado para a estrada: " << targetRoadId << endl;
    } else {
        EV << "Erro: Não foi possível encontrar uma estrada SUMO para a coordenada ("
           << targetCoord.x << ", " << targetCoord.y << "). O veículo pode estar fora da rede rodoviária." << endl;
    }
}
void ScenarioManager::addViaturas() {
    EV << "Adicionando veículo verde na simulação." << endl;

    //Atributos do veículo
    std::string vehicleId = "fugitivo";
    std::string vehicleType = "car";
    std::string routeId = "route0";
    double speed = 13.89;  // 50 km/h
    Coord headingVector(1, 0, 0);  // direção para o leste
    Heading heading = Heading::fromCoord(headingVector);

    VehicleSignalSet signals;  // pode ser vazio se não usar sinais

    double length = 4.5;  // exemplo: 4.5 metros
    double height = 1.5;  // exemplo: 1.5 metros
    double width = 1.8;   // exemplo: 1.8 metros

    // 1) Adiciona veículo no SUMO via TraCI (departTime=0 para sair imediatamente)
    getCommandInterface()->addVehicle(vehicleId, vehicleType, routeId, 0.0);

    // 2) Posição inicial do veículo (ajuste conforme sua necessidade)
    Coord initialPos(0, 0);

    // 3) Cria o módulo OMNeT++ associado ao veículo
    // moduleType, moduleName e displayString precisam existir no seu .ini ou código
    std::string moduleType = "siege.MyCar";  // Exemplo, ajuste conforme seu módulo de veículo
    std::string moduleName = vehicleId;
    std::string displayString = "";

    EV << "Veículo " << vehicleId << " adicionado2" << endl;
    addModule(vehicleId, moduleType, moduleName, displayString, initialPos, routeId, speed, heading, signals, length, height, width);

    EV << "Veículo " << vehicleId << " adicionado e colorido de vermelho." << endl;
}

} // namespace veins


