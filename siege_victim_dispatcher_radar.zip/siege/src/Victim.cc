//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "Victim.h"

Define_Module(Victim);

void Victim::initialize(int stage) {
    if (getIndex() == 0 && stage == 0) {
        cMessage *msg = new cMessage("assalto");
        scheduleAt(6.0, msg);  // Agenda o envio para t=6s

    }
}
void Victim::handleMessage(cMessage *msg)
{
    if (strcmp(msg->getName(), "assalto") == 0) {
        cMessage *msgEnviada = new cMessage("Fui assaltado, levaram meu carro placa XYZ-0000, marca X cor Y.");

        // Envia para a dispatcher usando sendDirect
        cModule *dispatcher = getParentModule()->getSubmodule("dispatcher");
        //cModule *radar0 = getParentModule()->getSubmodule("radar", 0);

        EV << "Destino da mensagem: " << dispatcher->getFullPath() << endl;

        sendDirect(msgEnviada, dispatcher, "veinsradioIn");

        delete msg;
    }
}

