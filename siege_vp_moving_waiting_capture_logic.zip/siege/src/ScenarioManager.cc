#include "ScenarioManager.h"
#include "Victim.h"

Define_Module(siege::ScenarioManager);

using namespace std;
using namespace veins;

static Coord localVitima;
cModule* fugitivo;
string idViatura;

namespace siege {

void ScenarioManager::initialize(int stage) {

    TraCIScenarioManagerLaunchd::initialize(stage);
    EV << "Meu ScenarioManager (siege) foi inicializado!" << endl;

    if (stage == 0) {
        // Agendar evento para sortear e designar o fugitivo após 5 segundos
        // Certifique-se de que os veículos já foram adicionados pelo SUMO/TraCI antes disso.
        cMessage* addViatura = new cMessage("addViatura");
        scheduleAt(simTime() +0.1, addViatura);

        cMessage* designateFugitivo = new cMessage("designateFugitivo");
        scheduleAt(simTime() +2, designateFugitivo);

        cMessage* moveViatura = new cMessage("moveViatura");
        scheduleAt(simTime() +2.1, moveViatura);

        distanciaPercorridaPeloFugitivo = -1;


    }
}

void ScenarioManager::finish(){
    recordScalar("distanciaPercorridaPeloFugitivo", distanciaPercorridaPeloFugitivo);

}

void ScenarioManager::handleMessage(cMessage* msg) {
    EV << "ScenarioManager: mensagem recebida: " << msg->getName() << endl;

    if (strcmp(msg->getName(), "designateFugitivo") == 0) {

        designateRandomFugitivo(); // Nova função para sortear e designar
        delete msg; // Lembre-se de deletar a mensagem após o uso
        return;
    }
    if (strcmp(msg->getName(), "moveViatura") == 0) {
            EV << "Entrou no if: Movendo viatura para ponto mais distante." << endl;
            // Exemplo de coordenada de destino (ajuste conforme sua necessidade)
            decideAndMoveFugitiveToFarthestCorner(idViatura);
            //Coord targetCoord(500, 500); // Exemplo: X=500, Y=500
            //moveToCoordinate("fugitivo", targetCoord); // Assumindo que "fugitivo" é o ID do veículo
            delete msg;
            return;
        }
    if (strcmp(msg->getName(), "addViatura") == 0) {
        //EV << "vai add viaturas agora --------------------------------." << endl;
        addViaturas();
        //EV << "terminou ----------------------------------------------." << endl;
        delete msg;
        return;
    }
    if (strcmp(msg->getName(), "response_time") == 0) {
            TraCIMobility* mobility = dynamic_cast<TraCIMobility*>(fugitivo->getSubmodule("veinsmobility"));
            Coord fugitivePosition = mobility->getPositionAt(simTime());
            //double distancia = localVitima.distance(fugitivePosition);
            double distancia = abs(fugitivePosition.x - localVitima.x) + abs(fugitivePosition.y - localVitima.y);

            distanciaPercorridaPeloFugitivo = distancia;

            //EV << "Distancia percorrida pelo fugitivo: " << distancia;
            delete msg; // Lembre-se de deletar a mensagem após o uso
            return;
        }
    if (msg->isSelfMessage()) {
        handleSelfMsg(msg);
        return;
    }
    throw cRuntimeError("erro no handleMessage de ScenarioManager)");
}

void ScenarioManager::designateRandomFugitivo() {
    // 1. Obter a lista de hosts gerenciados (veículos OMNeT++ com ID do SUMO)
    const std::map<std::string, cModule*>& managedHostsMap = getManagedHosts();

    // 2. Verificar a quantidade de veículos ativos
    // Embora activeVehicleCount exista, é mais direto usar o tamanho do mapa de hosts
    // gerenciados, pois ele já reflete os módulos OMNeT++ criados.
    if (managedHostsMap.empty()) {
        EV << "Nenhum veículo gerenciado encontrado no OMNeT++ para designar como fugitivo." << endl;
        return;
    }
    // 3. Criar um vetor de pares (ID SUMO, cModule*) para facilitar o sorteio por índice
    std::vector<std::pair<std::string, cModule*>> activeVehicles(managedHostsMap.begin(), managedHostsMap.end());


    // 4. Sortear um veículo aleatoriamente do vetor
    int randomIndex = omnetpp::intuniform(getParentModule()->getRNG(0), 0, activeVehicles.size() - 1);

    std::string fugitiveId = activeVehicles[randomIndex].first;
    cModule* fugitiveModule = activeVehicles[randomIndex].second;
    fugitivo = fugitiveModule;


    EV << "Veículo sorteado para ser o fugitivo: ID SUMO = " << fugitiveId << ", Módulo OMNeT++ = " << fugitiveModule->getFullName() << endl;


    // FAZER A VÍTIMA SURGIR NO LOCAL ONDE O VEÍCULO SE TORNOU FUGITIVO
    TraCIMobility* mobility = dynamic_cast<TraCIMobility*>(fugitiveModule->getSubmodule("veinsmobility"));
    Coord fugitivePosition = mobility->getPositionAt(simTime());
    localVitima = fugitivePosition;

    // Acessando 'victim[0]'
    //cModule* victimModule = getParentModule()->getSubmodule("victim", 0);
    Victim* victimModule = dynamic_cast<Victim*>(getParentModule()->getSubmodule("victim", 0));

    // MOvendo a vítima para o local onde o veículo se tornou fugitivo
    victimModule->getDisplayString().setTagArg("p", 0, std::to_string(fugitivePosition.x).c_str());
    victimModule->getDisplayString().setTagArg("p", 1, std::to_string(fugitivePosition.y).c_str());

    // 5. Opcional: Mudar a cor do veículo no SUMO (para visualização)
    fugitiveModule->getDisplayString().setTagArg("i", 1, "red");

    //--------------------------------------------------------------------------------------------------------------------------------- VARIÁVEIS DA SIMULAÇÃO AQUI
    cMessage* response_time = new cMessage("response_time");
    //68s - distância média neste intervalo de tempo
    scheduleAt(simTime() + 45 + 23, response_time);

    //34s - cenário médio onde as informações de localização e veículo são comunicadas antes do fim da mensagem
    //scheduleAt(simTime() + 22.5 + 11.5, response_time);

    //23s - cenário de acionamento por um único botão, com despachante comunicando toda a mensagem
    //scheduleAt(simTime() + 0 + 23, response_time);

    //11,5s - cenário de acionamento por um único botão, com informações de localização e veículo comunicadas antes do fim da mensagem
    //scheduleAt(simTime() + 0 + 11.5, response_time);
    //--------------------------------------------------------------------------------------------------------------------------------- FIM VARIÁVEIS DA SIMULAÇÃO

    decideAndMoveFugitiveToFarthestCorner(fugitiveId);

}
void ScenarioManager::decideAndMoveFugitiveToFarthestCorner(const std::string& vehicleId) {
    EV << "Decidindo a quina mais distante para o veículo " << vehicleId << endl;

    // 1. Obter a posição atual do veículo
    // Isso requer uma chamada TraCI para o veículo.
    // Certifique-se de que o veículo já foi adicionado ao SUMO.

    cModule* fugitiveModule = nullptr;
    const std::map<std::string, cModule*>& managedHostsMap = getManagedHosts();auto it = managedHostsMap.find(vehicleId);
    fugitiveModule = it->second;
    TraCIMobility* mobility = dynamic_cast<TraCIMobility*>(fugitiveModule->getSubmodule("veinsmobility"));
    Coord fugitivePosition = mobility->getPositionAt(simTime());

    // 2. Definir as coordenadas das quatro quinas do cenário
    // Use os mesmos limites que você usou para gerar a posição aleatória.
    // Certifique-se que estas variáveis (scenarioMinX, scenarioMaxX, etc.)
    // estão acessíveis aqui, talvez como membros da classe ou passadas de outra forma.
    // Substitua os 0.0 e 1000.0 pelos SEUS limites reais do cenário.
    double scenarioMinX = 100.0;  // Onde começa o seu mapa no eixo X
    double scenarioMaxX = 900.0; // Onde termina o seu mapa no eixo X
    double scenarioMinY = 100.0;  // Onde começa o seu mapa no eixo Y
    double scenarioMaxY = 900.0; // Onde termina o seu mapa no eixo Y


    std::vector<Coord> corners;
    corners.push_back(Coord(scenarioMinX, scenarioMinY, 0.0)); // Canto Inferior Esquerdo
    corners.push_back(Coord(scenarioMaxX, scenarioMinY, 0.0)); // Canto Inferior Direito
    corners.push_back(Coord(scenarioMinX, scenarioMaxY, 0.0)); // Canto Superior Esquerdo
    corners.push_back(Coord(scenarioMaxX, scenarioMaxY, 0.0)); // Canto Superior Direito

    // 3. Calcular a distância para cada quina e encontrar a mais distante
    double maxDistance = -1.0; // Usar -1 ou std::numeric_limits<double>::lowest() para garantir que qualquer distância seja maior
    Coord farthestCorner;

    for (const auto& corner : corners) {
        // Calcula a distância euclidiana (distância em linha reta)
        double distance = fugitivePosition.distance(corner);

        EV << "Distância de (" << fugitivePosition.x << ", " << fugitivePosition.y << ") para ("
           << corner.x << ", " << corner.y << ") = " << distance << endl;

        if (distance > maxDistance) {
            maxDistance = distance;
            farthestCorner = corner;
        }
    }

    EV << "A quina mais distante de (" << fugitivePosition.x << ", " << fugitivePosition.y
       << ") é (" << farthestCorner.x << ", " << farthestCorner.y << ") com distância de "
       << maxDistance << endl;

    // 4. Chamar a função original para mover o fugitivo para a quina mais distante
    moveToCoordinate(vehicleId, farthestCorner);
}

void ScenarioManager::moveToCoordinate(const std::string& vehicleId, const Coord& targetCoord) {
    EV << "Tentando mover veículo " << vehicleId << " para a coordenada: ("
       << targetCoord.x << ", " << targetCoord.y << ")" << endl;

    // 1. Converter a coordenada OMNeT++ para uma posição no mapa rodoviário do SUMO
    std::tuple<std::string, double, uint8_t> roadMapPos = getCommandInterface()->getRoadMapPos(targetCoord);
    std::string targetRoadId = std::get<0>(roadMapPos);
    double targetPos = std::get<1>(roadMapPos);
    uint8_t targetLane = std::get<2>(roadMapPos);

    if (!targetRoadId.empty()) {
        // 2. Usar changeTarget para definir a rota até a aresta de destino
        getCommandInterface()->vehicle(vehicleId).changeTarget(targetRoadId);

        // 3. Adicionar uma parada (stop) no ponto de destino
        // Usamos um tempo de espera negativo para que o veículo estacione no local destino para sempre.
        simtime_t indefiniteWaitTime = 200;
        getCommandInterface()->vehicle(vehicleId).stopAt(targetRoadId, targetPos, targetLane, 0.0, indefiniteWaitTime);

        EV << "Veículo " << vehicleId << " redirecionado e instruído a parar na estrada: " << targetRoadId << endl;
    } else {
        EV << "Erro: Não foi possível encontrar uma estrada SUMO para a coordenada ("
           << targetCoord.x << ", " << targetCoord.y << "). O veículo pode estar fora da rede rodoviária." << endl;
    }
}

void ScenarioManager::addViaturas() {
    EV << "Adicionando veículo azul em posição aleatória, com movimento a ser definido em tempo de execução." << endl;

    // --- Parâmetros a serem definidos pelo usuário ---
    // Tipo de aplicação para o módulo OMNeT++ do veículo
    std::string customApplType = "siege.Demo11p"; // Exemplo: "siege.MyApplication" ou "veins.base.appl.BaseApplLayer"

    // IMPORTANTE: Definir os limites do seu cenário aqui!
    // Substitua estes valores pelos limites reais (mínimo e máximo X, Y) do seu mapa SUMO.
    // Você pode encontrar esses valores no seu arquivo .net.xml ou ao inspecionar seu cenário no SUMO-GUI.
    double minX = 100.0;
    double maxX = 900.0; // Exemplo: Se o seu cenário vai de 0 a 1000 no eixo X
    double minY = 100.0;
    double maxY = 900.0; // Exemplo: Se o seu cenário vai de 0 a 1000 no eixo Y

    // Geração de posição aleatória
    // A função dblrand() retorna um double aleatório entre 0.0 (inclusive) e 1.0 (exclusive).
    double posX = minX + (maxX - minX) * dblrand();
    double posY = minY + (maxY - minY) * dblrand();
    double posZ = 0.0; // Geralmente 0 para simulações 2D no chão

    Coord randomPosition(posX, posY, 0.0);
    // -------------------------------------------------

    // Atributos do veículo
    std::string vehicleId = "viatura"; // ID único para o novo veículo no SUMO e OMNeT++
    std::string vehicleType = "DEFAULT_VEHTYPE";
    // IMPORTANTE: 'routeId' deve ser uma rota VÁLIDA no seu arquivo .rou.xml do SUMO.
    // Mesmo que o veículo não vá seguir a rota, o SUMO exige uma rota para adicioná-lo.
    // Use um dos IDs de veículo existentes no seu .rou.xml, como "t0", "t1", etc.
    std::string routeId = "rota_dinamica_1"; // ID da nova rota que você vai criar
        // ... (outros parâmetros como emitTime_st, etc.) ...


    // 1. CONVERTE A POSIÇÃO ALEATÓRIA PARA UMA ARESTA DO SUMO
    std::tuple<std::string, double, uint8_t> roadMapPos = getCommandInterface()->getRoadMapPos(randomPosition);
    std::string startEdgeId = std::get<0>(roadMapPos);
    double startLanePos = std::get<1>(roadMapPos);
    int8_t startLaneIndex = std::get<2>(roadMapPos);

    if (startEdgeId.empty()) {
        EV << "ERRO: Posição aleatória (" << posX << ", " << posY << ") não está em nenhuma estrada. Abortando a adição do veículo." << endl;
        return;
    }
    // 2. CRIA A ROTA DINÂMICA COMEÇANDO NA ARESTA ENCONTRADA
    std::list<std::string> edges;
    edges.push_back(startEdgeId); // A rota começa na aresta aleatória

    // Chamada para adicionar a rota ao SUMO
    getCommandInterface()->addRoute(routeId, edges);

    // Parâmetros adicionais para a função addVehicle
    simtime_t emitTime_st = 0.0;
    double emitPosition = 0; // Posição na aresta de partida (0 = no início da aresta)
    double emitSpeed = 22.0; // 80 km/h aproximadamente
    int8_t emitLane = 0; // Pista de partida (0 = pista mais à direita)

    double speed = 22.0; // Velocidade inicial definida como 22.0 para que o veículo se mova a 80km/h aproximadamente
    Coord headingVector(1, 0, 0); // Direção inicial (não relevante se o veículo está parado)
    Heading heading = Heading::fromCoord(headingVector);

    VehicleSignalSet signals; // Conjunto de sinais do veículo (pode ser vazio se não usar sinais específicos)

    double length = 4.5; // Comprimento do veículo em metros
    double height = 1.5; // Altura do veículo em metros
    double width = 1.8; // Largura do veículo em metros

    // 1) Adiciona o veículo no SUMO via TraCI
    // O departTime=0.0 faz com que ele apareça imediatamente no início da simulação.
    bool inserido = getCommandInterface()->addVehicle(vehicleId, vehicleType, routeId, emitTime_st, emitPosition, emitSpeed, emitLane);

    if (inserido == 0){
        EV << "Veiculo NÃO foi inserido!" << endl;
    }else{
        EV << "Veiculo inserido com sucesso!" << endl;
    }

    // 2) Define a posição inicial pré-definida do veículo no mapa usando os parâmetros
    Coord initialPos(posX, posY, posZ);

    // 3) Cria o módulo OMNeT++ associado ao veículo
    // 'siege.MyCar' é o tipo de módulo OMNeT++ que representa seu veículo.
    std::string moduleType = "siege.MyCar";
    std::string moduleName = vehicleId; // O nome do módulo OMNeT++ será o mesmo ID do veículo no SUMO

    // Define a displayString para o ícone do carro e sua cor (azul)
    // "i=veins/node/car_vs,blue" define o ícone e a cor.
    // "is=vs" define o tamanho do ícone para "veins size" (tamanho padrão do Veins).
    std::string displayString = "i=veins/node/car_vs,blue;is=vs";

    EV << "Criando módulo OMNeT++ para o veículo " << vehicleId << " na posição inicial ("
       << initialPos.x << ", " << initialPos.y << ", " << initialPos.z << ")." << endl;

    // Adiciona o módulo OMNeT++ à simulação.
    // O 'routeId' é passado aqui, mas será imediatamente sobrescrito pela chamada a moveToXY.
    addModule(vehicleId, moduleType, moduleName, displayString, initialPos, routeId, speed, heading, signals, length, height, width);

    // --- Configurar o tipo de aplicação e garantir a posição no SUMO ---
    // Acessar o módulo OMNeT++ recém-criado para configurar o 'applType' e sua posição no SUMO.
    // getManagedHosts() retorna um mapa de todos os módulos OMNeT++ gerenciados pelo ScenarioManager.
    cModule* addedModule = nullptr;
    const std::map<std::string, cModule*>& managedHostsMap = getManagedHosts();
    auto it = managedHostsMap.find(vehicleId); // Procura o módulo pelo seu ID
    if (it != managedHostsMap.end()) {
        addedModule = it->second; // Se encontrado, atribui o ponteiro
    }

    if (addedModule) {
        // 4) Definir o parâmetro 'applType' no módulo OMNeT++
        // Isso assume que o módulo 'siege.MyCar' tem um parâmetro 'applType' definido em seu NED.
        // Ex: em MyCar.ned, você teria: 'parameters: string applType = default("some.DefaultApp");'
        // Se 'MyCar' não tiver esse parâmetro, esta linha não terá efeito e um aviso será impresso.
        if (addedModule->hasPar("applType")) {
            // Reabilite esta linha se você precisar definir o applType programaticamente.
            // addedModule->par("applType").setString(customApplType.c_str());
            EV << "Parâmetro 'applType' do veículo " << vehicleId << " definido como: " << customApplType << endl;
        } else {
            EV << "Aviso: Módulo OMNeT++ '" << addedModule->getFullName() << "' não possui o parâmetro 'applType'. Não foi possível configurá-lo." << endl;
        }

    } else {
        EV << "ERRO: Não foi possível encontrar o módulo OMNeT++ recém-adicionado com ID '" << vehicleId << "' para configurar applType e posição no SUMO." << endl;
    }

    EV << "Veículo " << vehicleId << " adicionado, posicionado ALEATORIAMENTE em (" << initialPos.x
       << ", " << initialPos.y << ", " << initialPos.z << ") e colorido de azul. Movimento será controlado em runtime." << endl;

    idViatura = vehicleId;

}
} // namespace veins


